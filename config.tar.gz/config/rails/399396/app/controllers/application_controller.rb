class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception


  def sample
	config = Rails.configuration.database_configuration
	puts config
  end

end
