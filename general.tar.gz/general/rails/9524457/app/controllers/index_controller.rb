class IndexController < ApplicationController

	def index
		return render plain: 'hello_world'.camelize
	end
end
