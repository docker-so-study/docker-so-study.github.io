Rails.application.routes.draw do

	root 'index#index'

end
