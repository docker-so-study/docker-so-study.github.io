class IndexController < ApplicationController

	def index
		users = []
	
		u1 = User.new name: 'Test1'
		u2 = u1.dup

		users << u1
		users << u2

		return render json: users
	end

end
