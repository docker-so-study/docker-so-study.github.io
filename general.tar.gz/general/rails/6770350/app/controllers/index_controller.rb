class IndexController < ApplicationController


	def index
		user = User.new
		user.assign_attributes name: 'Test'

		return render json: user
	end

end
