class IndexController < ApplicationController


	def index
		@str = "Dear World,\n\nHello!"
	end
end
