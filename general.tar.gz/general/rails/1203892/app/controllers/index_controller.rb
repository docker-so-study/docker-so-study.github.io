class IndexController < ApplicationController

	def index
		current_uri = request.env['PATH_INFO']
		path = Rails.application.routes.recognize_path current_uri

		render json: path
	end

end
