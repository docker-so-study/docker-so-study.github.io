class IndexController < ApplicationController

	def index
		user = User.new name: 'test', test: 'test', 'password': 'test'

		render json: user.attributes
	end

end
