class IndexController < ApplicationController

	def index
		@str=  '<b>Hello, Workd</b>'
	end
end
