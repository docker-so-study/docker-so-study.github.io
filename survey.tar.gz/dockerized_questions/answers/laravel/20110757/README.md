StackOverflow Question [20110757](http://stackoverflow.com/questions/20110757)
===================

* To access the scripts, please check Dockerfile in corresponding question/answer directories. These instructions are concerned with running these scripts.

##### :page_facing_up: Artifacts

-  [Question directory](question)
  - Relevant Files : [Controller.php](question/app/app/Http/Controllers/Controller.php), [user.blade.php](question/app/resources/views/user.blade.php)
-  [Answer directory](answer)
  - Relevant Files : [Controller.php](answer/app/app/Http/Controllers/Controller.php), [user.blade.php](answer/app/resources/views/user.blade.php)

#### :computer: Running the container

###Answer

To run the container for the answer, you have to build the Docker image first:
```
cd answer
docker build -t answer . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 3000:3000 answer

Finally, you can open this link in your browser:
> http://localhost:3000/

*To run the question container, you have to change _answer_ for _question_*

---

**After you stop the container and delete the files, your computer will no longer have any traces of the question, nor any kind of files related to this StackOverflow question.**
