StackOverflow Question [12333739](http://stackoverflow.com/questions/12333739)
===================

* To access the scripts, please check Dockerfile in corresponding question/answer directories. These instructions are concerned with running these scripts.

##### :page_facing_up: Artifacts

-  [Answer directory](answer)
  - Relevant Files : [Controller.php](answer/app/app/Http/Controllers/Controller.php), [user.blade.php](answer/app/resources/views/user.blade.php)

#### :computer: Running the container

###Answer

To run the container for the answer, you have to build the Docker image first:
```
cd answer
docker build -t answer . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 3000:3000 answer

Finally, you can open this link in your browser:
> http://localhost:3000/

---

**After you stop the container and delete the files, your computer will no longer have any traces of the question, nor any kind of files related to this StackOverflow question.**
