exec composer install
exec php artisan migrate
php artisan serve --host=0.0.0.0 --port=3000
