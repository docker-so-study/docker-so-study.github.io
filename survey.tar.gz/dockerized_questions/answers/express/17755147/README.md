StackOverflow Question [17755147](http://stackoverflow.com/questions/17755147)
===================

* To access the scripts, please check Dockerfile in corresponding question/answer directories. These instructions are concerned with running these scripts.

##### :page_facing_up: Artifacts

-  [Question directory](question)
  - Relevant Files: [server.js](question/app/server.js), [index.ejs](question/app/views/index.ejs)
-  [Answer directory](answer)
  - Relevant Files : [server.js](answer/app/server.js), [index.ejs](answer/app/views/index.ejs)

#### :computer: Running the container

###Question

To run the container for the question, you have to build the Docker image first:
```
cd answer
docker build -t question . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 4000:4000 question

Finally, you can open this link in your browser:
> http://localhost:4000/

###Answer

To run the container for the answer, you have to build the Docker image first:
```
cd answer
docker build -t answer . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 4000:4000 answer

Finally, you can open this link in your browser:
> http://localhost:4000/

---

**After you stop the container and delete the files, your computer will no longer have any traces of the question, nor any kind of files related to this StackOverflow question.**