const express = require('express');
const app = express();
const PORT = 4000

app.get('/', function (req, res) {
    let isAjaxRequest = req.xhr;
    var message = `Is this request via AJAX? ${isAjaxRequest}`;
    console.log(message);
    res.send(message);
});

app.listen(PORT, function() {
    console.log(`Listening on port ${PORT}`);
});
