const express = require('express');
const app = express();
const PORT = process.env.PORT;

app.get('/one/two', function (req, res) {
    let fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    var message = `Full url: ${fullUrl}`;
    console.log(message);
    res.send(message);
});

app.listen(PORT, function () {
    console.log(`Server running on port ${PORT}.\nPlease, access /one/two`);
});
