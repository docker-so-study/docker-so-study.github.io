const express = require('express');
const app = express();
const PORT = process.env.PORT;

app.get('/one/two', function (req, res) {
    var url = req.url;
    res.send(`Url: ${url}`);
});

app.listen(PORT, function () {
    console.log(`Server running on port ${PORT}.\nPlease, access /one/two`);
});
