const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const app = express();

const PORT = process.env.PORT; 

app.use(express.bodyParser({uploadDir:'uploads/'}));

app.get('/', function (req, res) {
    res.sendfile(path.join(__dirname+'/index.html'));
});

app.get('/image.png', function (req, res) {
    res.sendfile(path.resolve('./uploads/image.png'));
}); 

app.post('/upload', function (req, res) {
    var tempPath = req.files.file.path,
        targetPath = path.resolve('./uploads/image.png');
    if (path.extname(req.files.file.name).toLowerCase() === '.png') {
        fs.rename(tempPath, targetPath, function(err) {
            if (err) throw err;
            console.log("Upload completed!");
        });
    } else {
        fs.unlink(tempPath, function () {
            console.log("Only .png files are allowed!");
        });
    }
    res.redirect('/');
});

app.listen(PORT, function() {
    console.log(`Listenning on PORT ${PORT}`);
});
