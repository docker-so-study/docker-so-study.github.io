StackOverflow Question [18807322](http://stackoverflow.com/questions/18807322)
===================

* To access the scripts, please check Dockerfile in corresponding question/answer directories. These instructions are concerned with running these scripts.

##### :page_facing_up: Artifacts

- [Question directory](question)
  - Relevant Files : [app.py](question/app/app.py), [models.py](question/app/models.py), [database.py](question/app/database.py), [index.html](question/app/templates/index.html)
- [Answer directory](answer)
  - Relevant Files : [app.py](answer/app/app.py), [models.py](answer/app/models.py), [database.py](answer/app/database.py), [index.html](answer/app/templates/index.html)


#### :computer: Running the container

###Question

To run the container for the question, you have to build the Docker image first:
```
cd question
docker build -t question . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 8000:8000 question

Finally, you can open this link in your browser:
> http://localhost:8000/

###Answer

To run the container for the answer, you have to build the Docker image first:
```
cd answer
docker build -t answer . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 8000:8000 answer

Finally, you can open this link in your browser:
> http://localhost:8000/

---

**After you stop the container and delete the files, your computer will no longer have any traces of the question, nor any kind of files related to this StackOverflow question.**
