from database import Base
from sqlalchemy import Column, Integer, ForeignKey, String, Boolean
from sqlalchemy.orm import relationship

class User(Base):
    """ Holds user info """

    __tablename__ = 'user'
    id = Column(Integer, primary_key=True)
    name = Column(String(25), unique=True)

    # relationships
    friends = relationship('Friend', backref='Friend.friend_id',primaryjoin='User.id==Friend.user_id', lazy='dynamic')

    def __init__(self, id, name):
        self.id = id
        self.name = name
    
    def __str__(self):
        return '<User %s>' % (self.name)

class Friend(Base):
    __tablename__ = 'friend'

    user_id = Column(Integer, ForeignKey(User.id), primary_key=True)
    friend_id = Column(Integer, ForeignKey(User.id), primary_key=True)

    def __init__(self, user_id, friend_id):
        self.user_id = user_id
        self.friend_id = friend_id

    def __str__(self):
        values = (self.user_id, self.friend_id)
        return '<FriendRelationship User<user_id: %s> Friend<user_id: %s>>' % values