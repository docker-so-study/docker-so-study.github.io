from database import Base
from sqlalchemy import Column, Integer, ForeignKey, String, Boolean
from sqlalchemy.orm import relationship

class User(Base):
    """ Holds user info """
    __tablename__ = 'user'

    id = Column(Integer, primary_key=True)
    name = Column(String(25), unique=True)

    def __init__(self, id, name):
        self.id = id
        self.name = name
    
    def __str__(self):
        return '<User %s>' % (self.name)

class Friend(Base):
    __tablename__ = 'friend'

    user_id = Column(Integer, ForeignKey(User.id), primary_key=True)
    friend_id = Column(Integer, ForeignKey(User.id), primary_key=True)

    user = relationship('User', foreign_keys='Friend.user_id')
    friend = relationship('User', foreign_keys='Friend.friend_id')

    def __init__(self, user_id, friend_id):
        self.user_id = user_id
        self.friend_id = friend_id

    def __str__(self):
        values = (self.user.id, self.user.name, self.friend.id, self.friend.name)
        return '<FriendRelationship User<user_id: %d, name: %s> Friend<user_id: %d name: %s>>' % values