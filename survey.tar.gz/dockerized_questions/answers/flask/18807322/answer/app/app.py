from flask import Flask, render_template
from database import db_session, init_db
from models import User, Friend

app = Flask(__name__)

@app.route('/')
def index():
    init_db()
    User.query.delete()
    Friend.query.delete()
    
    users = User.query.all()
    friends = Friend.query.all()
    
    if not users:
        user1 = User(1, 'user 1')
        user2 = User(2, 'user 2')
        db_session.add(user1)
        db_session.add(user2)
        db_session.commit()
        users = User.query.all()
    
    if not friends:
        friend = Friend(1, 2)    
        db_session.add(friend)
        db_session.commit()
        friends = Friend.query.all()

    return render_template('index.html', users=users, friends=friends)

@app.teardown_appcontext
def shutdown_session(exception=None):
    db_session.remove()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
