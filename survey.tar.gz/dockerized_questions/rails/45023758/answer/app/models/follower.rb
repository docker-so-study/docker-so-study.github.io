class Follower < ApplicationRecord
    belongs_to :user
end
