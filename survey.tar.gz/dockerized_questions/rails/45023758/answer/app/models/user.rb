class User < ApplicationRecord
    has_many :followers
end
