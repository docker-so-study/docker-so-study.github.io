class HomeController < ApplicationController

    def index
        render json: (User.all).sort_by{ |u| -u.followers.count }
    end

end
