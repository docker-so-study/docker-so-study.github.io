StackOverflow Question [45023758](http://stackoverflow.com/questions/45023758)
===================

* To access the scripts, please check Dockerfile in corresponding   question/answer directories.  These instructions are concerned with   running these scripts.

##### :page_facing_up: Artifacts

- [Question directory](question)
  - Relevant Files : [home_controller.rb](question/app/controllers/home_controller.rb), [routes.rb](question/config/routes.rb), [user.rb](question/app/models/user.rb), [follower.rb](question/app/models/follower.rb)), [migrate/](question/db/migrate), [seeds.rb](question/db/seeds.rb)
-  [Answer directory](answer)
  - Relevant Files : [home_controller.rb](answer/app/controllers/home_controller.rb), [routes.rb](answer/config/routes.rb), [user.rb](answer/app/models/user.rb), [follower.rb](answer/app/models/follower.rb)), [migrate/](answer/db/migrate), [seeds.rb](answer/db/seeds.rb)

#### :computer: Running the container

###Question

To run the container for the question, you have to build the Docker image first:
```
cd question
docker build -t question . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 3000:3000 question

Finally, you can open this link in your browser:
> http://localhost:3000/

###Answer

To run the container for the answer, you have to build the Docker image first:
```
cd answer
docker build -t answer . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 3000:3000 answer

Finally, you can open this link in your browser:
> http://localhost:3000/

---

**After you stop the container and delete the files, your computer will no longer have any traces of the question, nor any kind of files related to this StackOverflow question.**