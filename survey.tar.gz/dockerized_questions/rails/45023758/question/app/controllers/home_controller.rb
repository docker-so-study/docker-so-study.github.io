class HomeController < ApplicationController

    def index
        render json: User.all.order("followers.count DESC")
    end

end
