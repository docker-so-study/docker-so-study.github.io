class User < ApplicationRecord

    ActivityThreshold = 5.minutes


    def active_now!
        time_since_last_activity = [Time.now - last_seen_at, 0].max
        if time_since_last_activity <= ActivityThreshold
            self.total_time_online ||= 0
            self.total_time_online += time_since_last_activity
        end

        self.last_seen_at = Time.now
        save!
    end

end
