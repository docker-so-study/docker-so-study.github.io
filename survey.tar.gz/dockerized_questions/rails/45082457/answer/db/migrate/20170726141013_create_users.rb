class CreateUsers < ActiveRecord::Migration[5.1]
  def change
    create_table :users do |t|
      t.float :time_since_last_activity, default: 0
      t.time :last_seen_at, default: 0

      t.timestamps
    end
  end
end
