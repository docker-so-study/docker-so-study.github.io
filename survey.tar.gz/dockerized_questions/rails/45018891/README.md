StackOverflow Question [45018891](http://stackoverflow.com/questions/45018891)
===================

* To access the scripts, please check Dockerfile in corresponding   question/answer directories.  These instructions are concerned with   running these scripts.

##### :page_facing_up: Artifacts

- [Question directory](question)
  - Relevant Files : [home_controller.rb](question/app/controllers/home_controller.rb), [routes.rb](question/config/routes.rb), [index.html.erb](question/app/views/home/index.html.erb), [new.html.erb](question/app/views/home/new.html.erb), [go_back.js](question/app/assets/javascripts/go_back.js)
-  [Answer directory](answer)
  - Relevant Files : [home_controller.rb](answer/app/controllers/home_controller.rb), [routes.rb](answer/config/routes.rb), [index.html.erb](answer/app/views/home/index.html.erb), [new.html.erb](answer/app/views/home/new.html.erb), [go_back.js](answer/app/assets/javascripts/go_back.js), [application.js](answer/app/assets/javascripts/application.js)

#### :computer: Running the container

###Question

To run the container for the question, you have to build the Docker image first:
```
cd question
docker build -t question . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 3000:3000 question

Finally, you can open this link in your browser:
> http://localhost:3000/

###Answer

To run the container for the answer, you have to build the Docker image first:
```
cd answer
docker build -t answer . 
```

Then, you have to run the Docker container:
> docker run -it --rm -p 3000:3000 answer

Finally, you can open this link in your browser:
> http://localhost:3000/

---

**After you stop the container and delete the files, your computer will no longer have any traces of the question, nor any kind of files related to this StackOverflow question.**