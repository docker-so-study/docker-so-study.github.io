document.getElementById("back").addEventListener("click", function() {
    alert("You shall not pass!");
});